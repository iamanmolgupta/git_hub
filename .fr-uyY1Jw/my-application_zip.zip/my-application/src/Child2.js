import React from 'react';

class Child2 extends React.Component{

render(){
return(

<div>
  <h1>Welcome</h1>
</div>

)

}

}

export default Child2